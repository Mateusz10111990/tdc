module.exports = {
    database: {
        user: 'hr',
        password: 'oracle',
        connectString: 'localhost:1521/orcl'
    },
    jwtSecretKey: "jmvhDdDBMvqb=M@6h&QVA7x",
    api_ords: "http://localhost:8080/ords/hr"
};
